import fetch from '../util/fetch'
import server from '../util/request'

// 登录
export function getLogin(data){
    return fetch({
        method:'POST',
        url:'/react/login',
        data:data
    })
}
// // 用户登录请求接口函数
// export function getLogin(obj){
      
//     return server({
           
//        method:"POST",
//        url:"/api/login",
//        data:obj

//     })

// }
//获取动作类型列表
export function getAction(data){
    return fetch({
        method:'GET',
        url:'/react/index/action',
        params:data
    })
}
//动作展示列表（按分类:20种，数量：35)
export function getActionList(data){
    return fetch({
        method:'GET',
        url:'/react/index/actionList',
        params:data
    })
}
//获取计划列表
export function getPlan(data){
    return fetch({
        method:'GET',
        url:'/react/index/plan',
        params:data
    })
}
//获取课程列表
export function getCoures(data){
    return fetch({
        method:'GET',
        url:'/react/index/course',
        params:data
    })
}
//获取看点列表
export function getNews(data){
    return fetch({
        method:'GET',
        url:'/react/news/list',
        params:data
    })
}