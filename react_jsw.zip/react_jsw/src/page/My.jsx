import React, { Component } from 'react'
import { NavBar, Icon,Button,List, InputItem,Toast } from 'antd-mobile';
import { createForm } from 'rc-form';
import { getLogin } from '../api/common'
require('./My.css')

export default class My extends Component {
    constructor() {
        super();
        this.state = {
            users: false
        }
    }
    goLogin() {
        this.props.history.push({
            pathname: '/login',
        })
    }
    goUser(user_id){
        this.props.history.push({
            pathname: `/user/${user_id}`,
        })
    }
    componentDidMount() {
        if(sessionStorage.user_id){
             getLogin().then((res) => {
                console.log(res);

                this.setState({
                    users: res.data.data
                })
            })
        }
    }
    render() {
        
        return (
            <div>
                {this.state.users?<My_good users={this.state.users} gouser={(user_id)=>{this.goUser(user_id)}}/>:<My_login gologon={()=>{this.goLogin()}}/>}
            </div>
        )
    }
}

class My_login extends Component{
    constructor() {
        super();
    }
    goLogin(){
        this.props.gologon()
    }
    render(){
        return(
            <div className='My_login'>
                 <div className='header'>
                    <NavBar
                        mode="dark"
                        leftContent="我"
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    ></NavBar>
                </div>
                <div className='my_login'>
                    <div className='box1'>
                        <div className='gologin' onClick={()=>{this.goLogin()}}>
                            登录 / 注册
                        </div>
                    </div>
                    <ul className="box2">
                        <li onClick={()=>{this.goLogin()}}>计划</li>
                        <li onClick={()=>{this.goLogin()}}>美食</li>
                        <li onClick={()=>{this.goLogin()}}>邀约</li>
                        <li onClick={()=>{this.goLogin()}}>收藏</li>
                    </ul>
                </div>
            </div>
        )
    }
}

class My_good extends Component {
    constructor() {
        super();
    }
    goUser(user_id){
        // this.props.history.push({
        //     pathname: `/user`,
        // })
        this.props.gouser(user_id)
    }
    render(){
        let users = this.props.users
        return(
            <div className='My_good'>
                {/* {this.props.match.params.id} */}
                <div className='header'>
                    <NavBar
                        mode="dark"
                        leftContent="我"
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    ></NavBar>
                </div>

                <div className="my_header" onClick = {()=>{this.goUser(users.user_id)}}>
                    <div className="header_img">
                        <img src={users.header_img} alt="" />
                    </div>
                    <div className='header_rigth'>
                        <div className='nickname'>{users.nickname}</div>
                        <div className='autograph'>{users.autograph}</div>
                    </div>
                </div>

                <ul className='my_firstlist'>
                    <li>
                        <span>{users.follow}</span>
                        <span>关注</span>
                    </li>
                    <li>
                        <span>{users.fans}</span>
                        <span>粉丝</span>
                    </li>
                    <li>
                        <span>{users.news}</span>
                        <span>动态</span>
                    </li>
                    <li>
                        <span>{users.calorie}</span>
                        <span>卡路里币</span>
                    </li>
                </ul>

                <div className='my_data'>
                    <ul className='data data_left'>
                        <li>运动数据<Icon type="right" size='md' /></li>
                        <li>总运动</li>
                        <li><span className='motionNum'>{users.motionNum}</span>分钟</li>
                        <li>本周消耗<span>{users.motionNum}</span>千卡</li>
                    </ul>
                    <ul className='data data_rigth'>
                        <li>身体数据<Icon type="right" size='md' /></li>
                        <li>身高</li>
                        <li><span className='height'>{users.height}</span>cm</li>
                        <li>上次记录1天前</li>
                    </ul>
                    <ul className='data data_rigth'>
                        <li>个人消息<Icon type="right" size='md' /></li>
                        <li>消息</li>
                        <li><span className='height'>0</span>条</li>
                        <li>上次记录1天前</li>
                    </ul>
                    <ul className='data data_rigth'>
                        <li>健康指数<Icon type="right" size='md' /></li>
                        <li>健康</li>
                        <li><span className='height'>0</span>分</li>
                        <li>上次记录1天前</li>
                    </ul>
                </div>

                {/* <ul className='my_twolist'>
                    <li>1</li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul> */}
            </div>
        )
        
    }
}



