import React, { Component } from 'react'
import { getNews } from '../api/common'
require('./News.css');

export default class News extends Component {
    constructor() {
        super();
        this.state = {
            news: [],
            itemNum: 7,
            itemType: 'default',
            loadingTxt: '加载更多...',
        }
    }
    componentDidMount() {  ////组件被插入真实的节点，这个时候用户就能看到界面啦
        //看点列表
        getNews().then((res) => {
            this.setState({
                news: res.data.data
            })
        })
    }
    btnCurr(btnlen,btncurr,type){
        for(var i =0 ; i< btnlen ; i++){
            document.getElementById(type).parentNode.children[i].classList.remove('curr')
        }
        btncurr.classList.add("curr");
    }
    filterItem(type,id) {  //点击不同类型进行赛选
        var btnlen = document.getElementById(type).parentNode.children.length
        var btncurr = document.getElementById(type)
        switch (type) {
            case 'all':
                this.btnCurr(btnlen,btncurr,type)
                this.setState({
                    itemNum: this.state.news.length - 2,
                    itemType: 'all',
                    loadingTxt: '加载更多...'
                })
                break;
            case 'default': //前七个数据
                this.btnCurr(btnlen,btncurr,type)
                this.setState({
                    itemNum: 7,
                    itemType: 'default',
                    loadingTxt: '加载更多...'
                })
                break;
            default:
                this.btnCurr(btnlen,btncurr,type)
                this.setState({
                    itemType: type,
                    loadingTxt: '加载更多...'
                })
                break;
        }
    }
    getLoading() {//加载更多
        if (this.state.itemNum >= this.state.news.length) {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '暂无更多...'
                })
            }, 1000)
        } else {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '加载更多...',
                    itemNum: this.state.news.length,
                })
            }, 1000)
        }

    }
    goDetails(item) {
        this.props.history.push({
            pathname:`/details/_id?${item._id}`,
            query:{
                details_item:item,
                _id:item._id
            }
        })
    }
    render() {
        var newsLists = '';
        if (this.state.itemType == 'all') {
            newsLists = this.state.news.map((item, index) => {
                return item
            }).filter((item, index) => {
                return index < this.state.itemNum
            }).map((item, index) => {
                return <News_item
                    news_item={item}
                    ongoto={(item) => { this.goDetails(item) }}
                    key={item._id}
                />
            })
        } else if (this.state.itemType == 'default') {
            newsLists = this.state.news.map((item, index) => {
                return item
            }).filter((item, index) => {
                return index < this.state.itemNum
            }).map((item, index) => {
                return <News_item
                    news_item={item}
                    ongoto={(item) => { this.goDetails(item) }}
                    key={item._id}
                />
            })
        } else {
            newsLists = this.state.news.map((item, index) => {
                return item
            }).filter((item, index) => {
                return item.type == this.state.itemType
            }).map((item, index) => {
                return <News_item
                    news_item={item}
                    ongoto={(item) => { this.goDetails(item) }}
                    key={item._id}
                />
            })
        }
        return (
            <div className='Myindex clearfix'>
                <div className='index_header'>
                    <img src="http://m.jirou.com/templets/jirouweb/images/logo.png" alt="" className="header_logo" />
                </div>
                <div className="btn_box">
                    <button onClick={() => { this.filterItem('default') }} id='default' className='curr'>推荐</button>
                    <button onClick={() => { this.filterItem('all') }} id='all'>全部</button>
                    <button onClick={() => { this.filterItem('jianshen') }} id='jianshen'>健身</button>
                    <button onClick={() => { this.filterItem('meishi') }} id='meishi'>美食</button>
                    <button onClick={() => { this.filterItem('zaocan') }} id='zaocan'>早餐</button>
                    <button onClick={() => { this.filterItem('jihua') }} id='jihua'>计划</button>
                </div>
                <ul className='index_item_box News_item_box'>
                    {newsLists}
                </ul>
                <div className="loading_box" id='loading_box' onClick={() => { this.getLoading() }}>{this.state.loadingTxt}</div>
            </div>
        )

    }
}

//看点列表组件
class News_item extends Component {
    constructor() {
        super();
    }
    goDetails(item) {
        this.props.ongoto(item)
    }
    render() {
        return (
            <li className='index_item_item_2' onClick={() => { this.goDetails(this.props.news_item) }}>
                <div className='item_img'><img src={this.props.news_item.src} alt="" /></div>
                <div className="item_txt">
                    <div className='item_txt_top'>
                        {this.props.news_item.title}
                    </div>
                    <div className='item_txt_bootom'>
                        {this.props.news_item.time}
                    </div>
                </div>
            </li>
        )
    }
}
