import React, { Component } from 'react'
import { NavBar, Icon, Card } from 'antd-mobile';
import { getLogin } from '../api/common'
require('./User.css')

export default class User extends Component {
    constructor() {
        super();
        this.state = {
            users: []
        }
    }
    componentDidMount() {
        getLogin().then((res) => {
            this.setState({
                users: res.data.data
            })
        })

    }
    onLeftClick() {//返回
        this.props.history.push({
            pathname: `/my`,
        })
    }
    goUpdata_user() {
        this.props.history.push({
            pathname: `/updata_user`,
        })
    }

    render() {
        let users = this.state.users
        return (
            <div className='Myuser'>

                <div className='user_header'>
                    <NavBar
                        mode="light"
                        icon={<Icon type="left" />}
                        onLeftClick={() => { this.onLeftClick() }}
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    ></NavBar>
                </div>

                <div className='user_info'>
                    <div className='user_info_header'>
                        <div className="user_info_img">
                            <img src={users.header_img} alt="" />
                        </div>
                        <div className="user_info_updata" onClick={() => { this.goUpdata_user() }}>修改资料</div>
                    </div>
                    <div className='user_info_con'>
                        <p className='user_info_title'>{users.nickname}</p>
                        <p className='user_info'>
                            <span>{users.sex}  </span> |
                    <span>  {users.city}</span>
                        </p>
                    </div>
                    <ul className='user_info_footer'>
                        <li>
                            <span>{users.follow}</span>
                            <p>关注</p>
                        </li>
                        <li>
                            <span>{users.fans}</span>
                            <p>粉丝</p>
                        </li>
                        <li>
                            <span>{users.calorie}</span>
                            <p>获赞</p>
                        </li>
                    </ul>
                </div>

                <div className='user_footer'>
                    <Card>
                        <Card.Header
                            title="运动数据"
                            thumb="https://gw.alipayobjects.com/zos/rmsportal/MRhHctKOineMbKAZslML.jpg"
                            extra={<span>查看</span>}
                        />
                        <Card.Body>
                            <div>当前运动量为 <span style={{ fontWeight: "bold", fontSize: '25px' }}> {users.motionNum} </span> 分钟</div>
                        </Card.Body>
                        <Card.Footer content="已更新" extra={<div>2020-02-01</div>} />
                    </Card>

                </div>

            </div>
        )
    }
}
