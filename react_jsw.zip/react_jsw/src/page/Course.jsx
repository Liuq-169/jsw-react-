import React, { Component } from 'react'
import { SearchBar, Button, WhiteSpace, WingBlank, NavBar, Icon } from 'antd-mobile';
import { getCoures } from '../api/common'
import { NoticeBar } from 'antd-mobile';
require('./Course.css');
export default class Course extends Component {
    constructor(){
        super();
        this.state={
            value: '',
            courses:[],
            itemNum:8,
            loadingTxt: '加载更多...',
        }
    }
    componentDidMount(){
        //计划列表
        getCoures().then((res)=>{
            this.setState({
                courses: res.data.data
            })
        })
        
    }
    onLeftClick(){
        this.props.history.push({
            pathname:'/index',
        })
    }
    getLoading() {//加载更多
        if (this.state.itemNum >= this.state.courses.length) {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '暂无更多...'
                })
            }, 1000)
        } else {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '加载更多...',
                    itemNum: this.state.itemNum + 2,
                })
            }, 1000)
        }
    }
    goDetails(item){//跳转详情页面
        this.props.history.push({
            pathname:'/details',
            query:{
                details_item:item
            }
        })
    }
    render() {
        //课程列表
        var courseLists = this.state.courses.map((item, index) => {
            return item
        }).filter((item, index) => {
            return index < this.state.courses.length
        }).map((item, index) => {
            return <Index_course
                godetails={(item)=>{this.goDetails(item)}}
                course_item={item}
                key={item._id}
            />
        })
        console.log(courseLists);
        
        return (
            <div className='Mycoures clearfix'>
                    <div className='search_header'>
                    {/* <img src="http://m.jirou.com/templets/jirouweb/images/logo.png" alt="" className="header_logo" /> */}
                    <NavBar
                        mode="light"
                        icon={<Icon type="left" />}
                        onLeftClick={() => { this.onLeftClick() }}
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    >课程合辑</NavBar>
                </div>
                <div className="search_box">
                    <SearchBar
                        value={this.state.value}
                        placeholder="搜索"
                        onSubmit={value => console.log(value, 'onSubmit')}
                        onClear={value => console.log(value, 'onClear')}
                        onFocus={() => console.log('onFocus')}
                        onBlur={() => console.log('onBlur')}
                        onCancel={() => console.log('onCancel')}
                        showCancelButton
                        onChange={this.onChange}
                    />
                </div>
                <div className='index_course index_item'>
                    <div className='header clearfix'>
                    </div>
                    <ul className='index_item_box'>
                        {courseLists}
                    </ul>
                </div>
                <div className="loading_box" id='loading_box' onClick={() => { this.getLoading() }}>{this.state.loadingTxt}</div>
            </div>
        )
    }
}

//课程合辑组件
class Index_course extends Component {
    constructor() {
        super();
    }
    goDetails(item){
        this.props.godetails(item)
    }
    render() {
        return (
            <li className='index_item_item_3' onClick = {()=>{this.goDetails(this.props.course_item)}}>
                <img src={this.props.course_item.src} alt="" />
            </li>
        )
    }
}
