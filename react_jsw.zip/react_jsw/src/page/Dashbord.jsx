import React,{lazy,Suspense,Component} from 'react'
import {BrowserRouter as Router ,Route,Link,NavLink,Redirect} from "react-router-dom"
import News from './News'
let Index = lazy(()=>import('./Index')) //
let Search = lazy(()=>import('./Action')) //
let My = lazy(()=>import('./My')) //


export default class Dashbord extends Component {
    constructor() {
        super()
    }
    render() {
        return (
            <div className=''>
                
                <div className='container'>
                    <Suspense fallback={<div>Loading...</div>}>
                        <Route path='/index'
                            component={Index}>

                        </Route>
                        <Route path='/news'
                            component={News}>

                        </Route>
                        <Route path='/my'
                            component={My}>

                        </Route>
                        {/* <Redirect from='/' to='/index'></Redirect> */}
                    </Suspense>
                </div>
                <div className='navList'>
                    <div><NavLink to="/index">首页</NavLink></div>
                    <div><NavLink to="/news">看点</NavLink></div>
                    <div><NavLink to='/my'>我的</NavLink></div>
                </div>
            </div>
        )
    }
}