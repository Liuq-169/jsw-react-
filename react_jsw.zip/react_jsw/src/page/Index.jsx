import React, { Component } from 'react'
import { Carousel, WingBlank } from 'antd-mobile';
import { connect } from 'react-redux'
import { getAction,getPlan,getCoures } from '../api/common'
import { deletecomment, syncfetchcomment } from '../store/actions/comment'
require('./Index.css');

class Index extends Component {
    constructor() {
        super()
        this.state = {
            data: ['1', '2', '3'],
            imgHeight: 128,
            
            actions: [],
            plans:[],
            coures:[]
        }
    }
    componentWillMount() { //钩子函数  ////在插入真实节点之前
        this.props.dispatch(syncfetchcomment())//加载创建的数据
        // this.props.dispatch(deletecomment('1'))//对数据进行删除
    }

    componentDidMount() {  ////组件被插入真实的节点，这个时候用户就能看到界面啦
        setTimeout(() => { //走马灯
            this.setState({
                data: [0, 1, 2],
            });
        }, 100);

        //动作列表渲染
        //往后台发请求
        getAction().then((res) => {
            this.setState({
                actions: res.data.data
            })
        })
        //计划列表
        getPlan().then((res)=>{
            this.setState({
                plans: res.data.data
            })
        })
        //课程列表
        getCoures().then((res)=>{
            this.setState({
                coures: res.data.data
            })
        })

    }

    goCenter() {//页面跳转函数
        //js导航

        //可以访问历史
        //接字符串 this.props.history.push("/user/liuq?a=1")
        //接对象
        // this.props.history.push({
        //     pathname:'/index/user/liuq',
        //     search:'?a=1' //组件切换的时候，携带参数：动态路由，search
        // })

        //replace --不可回退页面 --一般用于登录的时候

        //goBack() 回到上一个路由

        this.props.history.push({
            pathname: 'Index/mine',
        })
    }

    goAction(ename,name) {//跳转动作列表页面
        this.props.history.push({
            pathname: `index/action/?ename=${ename}`,
            query:{
                type_name:name,
            }
        })
    }

    goPlan(){//跳转计划页面
        this.props.history.push({
            pathname:'index/plan'
        })
    }
    goCourse(){//跳转课程合辑页面
        this.props.history.push({
            pathname:'index/course'
        })
    }

    goDetails(item){//跳转详情页面
        this.props.history.push({
            pathname: `/details`,
            query:{
                details_item:item,
            }
        })
    }

    getArrayProps(array, key) {  //将获取返回的对象数组的某一属性，结合为一个一维数组
        var key = key || "value";
        var res = [];
        if (array) {
            array.forEach(function (t) {
                res.push(t[key]);
            });
        }
        return res;
    }

    render() {

        let { list } = this.props
        // console.log(list);

        let Carousel_src = list.reduce((pre, cur) => pre.concat(cur.src), [])
        // var name = this.getArrayProps(list,'name')

        //动作组件
        var actionLists = this.state.actions.map((item, index) => {
            return item
        }).filter((item, index) => {
            return index < 8
        }).map((item, index) => {
            return <Index_action
                goaction={(ename,name)=>{this.goAction(ename,name)}}
                action_item={item}
                key={item._id}
            />
        })
        //计划列表
        var planLists = this.state.plans.map((item, index) => {
            return item
        }).filter((item, index) => {
            return index < 5
        }).map((item, index) => {
            return <Index_plan
                godetails={(item)=>{this.goDetails(item)}}
                plan_item={item}
                key={item._id}
            />
        })
        //课程列表
        var courseLists = this.state.coures.map((item, index) => {
            return item
        }).filter((item, index) => {
            return index < 3
        }).map((item, index) => {
            return <Index_course
                godetails={(item)=>{this.goDetails(item)}}
                course_item={item}
                key={item._id}
            />
        })

        return (
            <div className='Myindex clearfix'>
                <div className='index_header'>
                    <img src="http://m.jirou.com/templets/jirouweb/images/logo.png" alt="" className="header_logo" />
                </div>
                {/* 走马灯 */}
                <WingBlank>
                    <Carousel className="space-carousel"
                        frameOverflow="visible"
                        cellSpacing={10}
                        slideWidth={0.8}
                        autoplay
                        infinite
                        afterChange={index => this.setState({ slideIndex: index })}
                    >
                        {this.state.data.map((val, index) => (
                            <a
                                key={val}
                                href="http://www.alipay.com"
                                style={{
                                    display: 'block',
                                    position: 'relative',
                                    top: this.state.slideIndex === index ? -10 : 0,
                                    height: this.state.imgHeight,
                                    boxShadow: '2px 1px 1px rgba(0, 0, 0, 0.2)',
                                }}
                            >
                                <img
                                    src={Carousel_src[val]}
                                    alt=""
                                    style={{ width: '100%', height: '128px', verticalAlign: 'top' }}
                                    onLoad={() => {
                                        // fire window resize event to change height
                                        window.dispatchEvent(new Event('resize'));
                                        this.setState({ imgHeight: 'auto' });
                                    }}
                                />
                            </a>
                        ))}
                    </Carousel>
                </WingBlank>

                {/* 动作 */}
                <div className='index_action index_item'>
                    <div className='header clearfix'>
                        <span className='item_txt'><i>| </i> 动作</span>
                        <span className='item_btn'>
                            <button onClick={() => { this.goAction('false','false') }}>更多></button>
                        </span>
                    </div>
                    <ul className='index_item_box'>
                        {actionLists}
                    </ul>
                </div>
                {/* 计划 */}
                <div className='index_plan index_item'>
                    <div className='header clearfix'>
                        <span className='item_txt'><i>| </i> 推荐计划</span>
                        <span className='item_btn'>
                            <button onClick={() => { this.goPlan() }}>更多></button>
                        </span>
                    </div>
                    <ul className='index_item_box'>
                        {planLists}
                    </ul>
                </div>
                {/* 课程 */}
                <div className='index_course index_item'>
                    <div className='header clearfix'>
                        <span className='item_txt'><i>| </i> 课程合辑</span>
                        <span className='item_btn'>
                            <button onClick={() => { this.goCourse() }}>更多></button>
                        </span>
                    </div>
                    <ul className='index_item_box'>
                        {courseLists}
                    </ul>
                </div>
                <div className='footer'>
                    <img src="http://m.jirou.com/templets/jirouweb/images/footer.png" alt="" />
                </div>
            </div>
        )
    }
}

//动作列表组件
class Index_action extends Component {
    constructor() {
        super();
    }
    goAction(ename,name){
        this.props.goaction(ename,name)
    }
    render() {
        return (
            <li className='index_item_item' onClick={()=>{this.goAction(this.props.action_item.ename,this.props.action_item.name)}}>
                <img src={this.props.action_item.src} alt="" />
                <p>{this.props.action_item.name}</p>
            </li>
        )
    }
}

//推荐计划组件
class Index_plan extends Component {
    constructor() {
        super();
    }
    goDetails(item){
        this.props.godetails(item)
    }
    render() {
        return (
            <li className='index_item_item_2' onClick={()=>{this.goDetails(this.props.plan_item)}}>
                <div className='item_img'><img src={this.props.plan_item.src} alt="" /></div>
                <div className="item_txt">
                    <div className='item_txt_top'>
                        {this.props.plan_item.title}
                </div>
                    <div className='item_txt_bootom'>
                        {this.props.plan_item.time}
                </div>
                </div>
            </li>
        )
    }
}

//课程合辑组件
class Index_course extends Component {
    constructor() {
        super();
    }
    goDetails(item){
        this.props.godetails(item)
    }
    render() {
        return (
            <li className='index_item_item_3' onClick={()=>{this.goDetails(this.props.course_item)}}>
                <img src={this.props.course_item.src} alt="" />
            </li>
        )
    }
}



const mapStateToProps = (state) => {
    return {//配置映射
        list: state
    }
}
export default connect(
    //映射数据，把仓库 的state映射到 组件的props上   
    mapStateToProps//就把store的state映射到组件的prop上   
)(Index)