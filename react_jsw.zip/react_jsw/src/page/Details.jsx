import React, { Component } from 'react'
import { NavBar, Icon, NoticeBar, WhiteSpace } from 'antd-mobile';
import { getNews } from '../api/common'
require('./Details.css');

export default class Details extends Component {
    constructor(props) {
        super(props);
        this.state = {
            recommends: [],
            recommendNum: 8,
            details_item: props.location.query.details_item,
            details_id:props.location.query._id,
            islike:false
        }
    }
    componentDidMount() {  ////组件被插入真实的节点，这个时候用户就能看到界面啦
        //相关列表
        getNews().then((res) => {
            this.setState({
                recommends: res.data.data
            })
        })
        console.log(this.state.details_item);

    }
    goNews() { //回到看点
        this.props.history.push({
            pathname: '/news',
        })
        // console.log(1);&& item._id == this.state.details_item._id
    }
    iLike(){//收藏

        this.setState({
            islike:this.state.islike?false:true
        })

    }
    onDetails(id){ //切换页面内容
        console.log(id);
        this.setState({
            details_item:this.state.recommends.filter((item,index)=>{
                return item._id == id
            })[0],
            details_id:id
        })
    }

    render() {
        var recommentLists = this.state.recommends.map((item, index) => {
            return item
        }).filter((item, index) => {
            return index < this.state.recommendNum && item._id != this.state.details_item._id
        }).map((item, index) => {
            return <Recommend_item
                recommends_item={item}
                key={item._id}
                ondetails={(id)=>{this.onDetails(id)}}
            />
        })
        return (
            <div className="Mydetails">
                <NavBar
                    mode="light"
                    icon={<Icon type="left" />}
                    onLeftClick={() => { this.goNews() }}
                    rightContent={[
                        <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                        <Icon key="1" type="ellipsis" />,
                    ]}
                >肌肉网</NavBar>
                <p className="title" title={this.state.details_item.title}>{this.state.details_item.title}</p>
                <div className='user_box'>
                    <div className='user_header_img'>
                        <img src={this.state.details_item.header_img} alt="" />
                    </div>
                    <div className='user_name'>{this.state.details_item.user_name}</div>
                    <div className='like' onClick={()=>{this.iLike()}}>
                        {this.state.islike?'已收藏':'收藏'}
                    </div>
                </div>
                <p className="info">
                    {this.state.details_item.info}
                </p>
                <div className='details_img'>
                    <img src={this.state.details_item.src} alt="" />
                </div>
                <p className='details_time'>发表时间:{this.state.details_item.time}</p>
                <div className=' index_item'>
                    <div className='header clearfix'>
                        <span className='item_txt'><i>| </i> 相关推荐</span>
                    </div>
                    <ul className='index_item_box'>
                        {recommentLists}
                    </ul>
                </div>

                <NoticeBar mode="link" onClick={() => alert('谢谢您的支持!')}>
                    This article is owned by the author.
                    If you need to check the original or reprint it,
                    please contact the author. Please understand. Thank you!
                </NoticeBar>
                <div className='details_footer'>
                    <img src="http://m.jirou.com/templets/jirouweb/images/footer.png" alt="" />
                </div>
            </div>
        )
    }
}

//相关推荐列表组件
class Recommend_item extends Component {
    constructor() {
        super();
    }
    onDetails(id){
        this.props.ondetails(id)
    }
    render() {
        return (
            <li className='index_item_item_2' onClick={()=>{this.onDetails(this.props.recommends_item._id)}}>
                <div className='item_img'><img src={this.props.recommends_item.src} alt="" /></div>
                <div className="item_txt">
                    <div className='item_txt_top'>
                        {this.props.recommends_item.title}
                    </div>
                    <div className='item_txt_bootom'>
                        {this.props.recommends_item.time}
                    </div>
                </div>
            </li>
        )
    }
}