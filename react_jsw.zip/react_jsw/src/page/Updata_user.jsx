import React, { Component } from 'react'
import { NavBar, Icon } from 'antd-mobile';
import { getLogin } from '../api/common'
require('./Updata_user.css')

export default class Updata_user extends Component {
    constructor() {
        super();
        this.state = {

        }
    }
    onLeftClick(user_id) {
        this.props.history.push({
            pathname: `/user/${user_id}`,
        })
    }
    componentDidMount() {
        getLogin().then((res) => {
            console.log(res.data.data);
        })
    }
    render() {
        return (
            <div className='Myupdata'>
                <div className='updata_header'>
                    <NavBar
                        mode="light"
                        icon={<Icon type="left" />}
                        onLeftClick={() => { this.onLeftClick(sessionStorage.user_id) }}
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    >个人资料</NavBar>
                </div>
                <ul className='updata_con'>
                    <li>
                        <span>昵称</span> <input type="text" value='昵称' />
                    </li>
                    <li>
                        <span>性别</span> <input type="text" value='男' />
                    </li> 
                    <li>
                        <span>生日</span> <input type="text" value='昵称' />
                    </li>
                    <li>
                        <span>所在城市</span> <input type="text" value='昵称' />
                    </li>
                </ul>
                <div className="footer">
                    <p>简历</p>
                    <textarea name="" id="" cols="30" rows="10" placeholder='请在此处输入简历'></textarea>
                </div>
            </div>
        )
    }
}
