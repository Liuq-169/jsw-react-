import React, { Component } from 'react'
import { List, InputItem, Toast, ActionSheet, WingBlank, WhiteSpace, Button } from 'antd-mobile'
import { createForm } from 'rc-form'
import { getLogin } from '../api/common'
require('./Login.css')
class Login extends Component {
    constructor() {
        super();
        this.state = {
            users: [],
            clicked: 'none',
            clicked1: 'none',
            clicked2: 'none',
        }
    }
    componentDidMount() {
        getLogin().then((res) => {
            this.setState({
                users: res.data.data
            })
        })
    }
    showShareActionSheet = () => {

        var dataList = [
            { url: 'OpHiXAcYzmPQHcdlLFrc', title: '发送给朋友' },
            { url: 'wvEzCMiDZjthhAOcwTOu', title: '新浪微博' },
            { url: 'cTTayShKtEIdQVEMuiWt', title: '生活圈' },
            { url: 'umnHwvEgSyQtXlZjNJTt', title: '微信好友' },
            { url: 'SxpunpETIwdxNjcJamwB', title: 'QQ' },
        ].map(obj => ({
            icon: <img src={`https://gw.alipayobjects.com/zos/rmsportal/${obj.url}.png`} alt={obj.title} style={{ width: 36 }} />,
            title: obj.title,
        }));

        ActionSheet.showShareActionSheetWithOptions({
            options: dataList,
            // title: 'title',
            message: 'I am description, description, description',
        },
            (buttonIndex) => {
                this.setState({ clicked1: buttonIndex > -1 ? dataList[buttonIndex].title : 'cancel' });
                // also support Promise
                return new Promise((resolve) => {
                    Toast.info('closed after 1000ms');
                    setTimeout(resolve, 1000);
                });
            });
    }

    submit() {
        this.props.form.validateFields((error, value) => {
            if (error) {
                if (error.password) {
                    Toast.fail("密码为空或者输入错误", 1)
                    return
                }
            } else {
                //往后台发请求
                getLogin().then((res) => {
                    console.log(res);
                    console.log(this.state.users);
                    let users = this.state.users
                    if (value.text == users.user_name && value.password == users.password) {
                        sessionStorage.user_id = users.user_id
                        this.props.history.push({
                            pathname: `/my/${users.user_id}`,
                        })
                    } else {
                        Toast.fail("用户名或密码输入错误", 1)
                        return
                    }

                })
            }

        })

    }
    render() {
        const { getFieldProps } = this.props.form;
        const isIPhone = new RegExp('\\biPhone\\b|\\biPod\\b', 'i').test(window.navigator.userAgent);
        let moneyKeyboardWrapProps;
        if (isIPhone) {
            moneyKeyboardWrapProps = {
                onTouchStart: e => e.preventDefault(),
            };
        }
        return (
            <div className='Mylogin'>
                <List renderHeader={() => '手机号登录/注册'}>
                    <InputItem
                        {...getFieldProps('text')}
                        type="text"
                        defaultValue={100}
                        placeholder="请输入用户名"
                        clear
                        moneyKeyboardAlign="left"
                        moneyKeyboardWrapProps={moneyKeyboardWrapProps}
                    >用户名</InputItem>
                    <InputItem
                        {...getFieldProps('password', { rules: [{ required: true }] })}
                        type="password"
                        placeholder="请输入密码"
                    >密码</InputItem>
                    <Button onClick={() => { this.submit() }}>登录</Button>
                </List>
                <div className='switch_box'>
                    <Button onClick={this.showShareActionSheet} className='switch'>其他登录方式</Button>
                </div>
                
            </div>
        )
    }
}

export default createForm()(Login)//高阶组件