import React, { Component } from 'react'
import { SearchBar, Button, WhiteSpace, WingBlank, NavBar, Icon } from 'antd-mobile';
import { NoticeBar } from 'antd-mobile';
import { getAction,getActionList } from '../api/common'
require('./Action.css');
export default class Search extends Component {
    constructor(props) {
        super(props)
        this.state = {
            value: '',
            actionType: [],
            actionTitle: props.location.query.type_name=='false'?'全部':props.location.query.type_name,
            actionList:[],
            itemNum: 7,
            itemType: this.getQueryString()=='false'?'defaul':this.getQueryString(),
            loadingTxt: '加载更多...',
        }
    }
    getQueryString() { //获取url的=号后面的参数
        var url = window.location.search; 
        var loc = url.substring(url.lastIndexOf('=')+1, url.length); 
        return loc
    }
    componentDidMount() {
        getAction().then((res) => { //动作类型
            this.setState({
                actionType: res.data.data
            })
        })

        getActionList().then((res) => { //动作展示列表
            this.setState({
                actionList: res.data.data
            })
        })
        console.log(this.state.itemType);
       
         
    }
    onLeftClick() {//返回首页
        this.props.history.push({
            pathname: '/index'
        })
    }
    onChange = (value) => {
        this.setState({ value });
    };
    TagonChange(selected) {
        console.log(`tag selected: ${selected}`);
    };

    filterItem(type,name){//点击不同类型进行赛选
        console.log(type,name);
        
        this.setState({
            itemType:type,
            actionTitle:name
        })
    }

    goDetails(item) {//跳转详情details页面
        this.props.history.push({
            pathname:`/details/_id?${item._id}`,
            query:{
                details_item:item,
                _id:item._id
            }
        })
    }

    getLoading() {//加载更多
        if (this.state.itemNum >= this.state.actionList.length) {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '暂无更多...'
                })
            }, 1000)
        } else {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '加载更多...',
                    itemNum: this.state.itemNum + 8,
                })
            }, 1000)
        }
    }


    render() {
        // console.log(this.state.actionList);
        
        var buwei_List = this.state.actionType.filter((item, index) => {  //动作类型
            return item.type == 'buwei'
        }).map((item) => {
            return <Tag
                item={item}
                key={item._id} 
                onfilter={(type,name)=>{this.filterItem(type,name)}}
                />
        })

        var jirou_List = this.state.actionType.filter((item, index) => {  //动作类型
            return item.type == 'jirou'
        }).map((item) => {
            return <Tag
                item={item}
                key={item._id}
                onfilter={(type,name)=>{this.filterItem(type,name)}}
                />
        })

        
        
        var action_List = ''
        if(this.state.itemType == 'defaul'){ //动作看点展示

            action_List = this.state.actionList.filter((item, index) => {  //动作展示列表
                return index <= this.state.itemNum
            }).map((item) => {
                return <ActionItem 
                        item={item}
                        key={item._id}
                        ongodetails={(item)=>{this.goDetails(item)}}
                        />
            })

        }else{
            action_List = this.state.actionList.filter((item, index) => {  //动作展示列表
                return  item.type == this.state.itemType
            }).map((item) => {
                return <ActionItem 
                        item={item}
                        key={item._id}
                        ongodetails={(item)=>{this.goDetails(item)}}
                        />
            })
        }
        console.log(action_List);
        

        return (
            <div className='Mysearch clearfix'>
                <div className='search_header'>
                    {/* <img src="http://m.jirou.com/templets/jirouweb/images/logo.png" alt="" className="header_logo" /> */}
                    <NavBar
                        mode="light"
                        icon={<Icon type="left" />}
                        onLeftClick={() => { this.onLeftClick() }}
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    >动作</NavBar>
                </div>
                <div className="search_box">
                    <SearchBar
                        value={this.state.value}
                        placeholder="搜索"
                        onSubmit={value => console.log(value, 'onSubmit')}
                        onClear={value => console.log(value, 'onClear')}
                        onFocus={() => console.log('onFocus')}
                        onBlur={() => console.log('onBlur')}
                        onCancel={() => console.log('onCancel')}
                        showCancelButton
                        onChange={this.onChange}
                    />
                </div>
                <div className='tag_box'>
                    <div className='tag_name'>部位:</div>
                    <div className="tag">
                        {buwei_List}
                    </div>
                </div>
                <div className='tag_box'>
                    <div className='tag_name'>肌肉:</div>
                    <div className="tag">
                        {jirou_List}
                    </div>
                </div>
                <div className='index_action index_item'>
                    <div className='header clearfix'>
                    <span className='item_txt'><i>| </i> {this.state.actionTitle}</span>
                    </div>
                    <ul className='index_item_box action_item_box'>
                        {action_List}
                    </ul>
                </div>
                <div className="loading_box" id='loading_box' onClick={() => { this.getLoading() }}>{this.state.loadingTxt}</div>
                <NoticeBar mode="link" onClick={() => alert('谢谢您的支持!')}>
                    This article is owned by the author. If you need to check the original or reprint it, please contact the author. Please understand. Thank you!
                </NoticeBar>
                <div className='footer'>
                    <img src="http://m.jirou.com/templets/jirouweb/images/footer.png" alt="" />
                </div>
            </div>
        )
    }
}
class Tag extends Component{
    constructor(){
        super();
    }
    getQueryString() { //获取url的=号后面的参数
        var url = window.location.search; 
        var loc = url.substring(url.lastIndexOf('=')+1, url.length); 
        return loc
    }

    componentDidMount(){
        if(this.getQueryString()!='false'){
            document.getElementById(this.getQueryString()).classList.add("action_curr");
        }
    }

    btnCurr(btnlen,btncurr,ename){
        for(var i =0 ; i< btnlen ; i++){
            document.getElementById(ename).parentNode.children[i].classList.remove('action_curr')
        }
        btncurr.classList.add("action_curr");
    }
    
    onCurr(ename,name){
        var btnlen = document.getElementById(ename).parentNode.children.length
        var btncurr = document.getElementById(ename)
        this.btnCurr(btnlen,btncurr,ename)
        this.props.onfilter(ename,name)
    }
    render(){
        return(
                <button 
                id= {this.props.item.ename} 
                onClick={()=>{this.onCurr(this.props.item.ename,this.props.item.name)}}
                >
                    {this.props.item.name}
                </button>
        )
            
    }
}

class ActionItem extends Component {
    constructor() {
        super()
    }
    goDetails(item){
        this.props.ongodetails(item)      
    }
    render() {
        return (
            <li className='index_item_item_2' onClick={()=>{this.goDetails(this.props.item)}}>
                <div className='item_img'>
                    <img src={this.props.item.src} alt=""/>
                </div>
                <div className="item_txt">
                    <div className='item_txt_top'>
                        {this.props.item.title}
                    </div>
                    <div className='item_txt_bootom'>
                        {this.props.item.time}
                    </div>
                </div>
            </li>
        )
    }
}