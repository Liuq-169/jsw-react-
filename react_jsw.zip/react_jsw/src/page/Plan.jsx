import React,{Component} from 'react'
import { SearchBar, Button, WhiteSpace, WingBlank, NavBar, Icon } from 'antd-mobile';
import { getPlan } from '../api/common'
import { NoticeBar } from 'antd-mobile';
require('./Plan.css');
export default class Mine extends Component{
    constructor(){
        super();
        this.state={
            value: '',
            plans:[],
            itemNum:8,
            loadingTxt: '加载更多...',
        }
    }
    componentDidMount(){
        //计划列表
        getPlan().then((res)=>{
            this.setState({
                plans: res.data.data
            })
        })
    }
    onLeftClick(){
        this.props.history.push({
            pathname:'/index',
        })
    }
    getLoading() {//加载更多
        if (this.state.itemNum >= this.state.plans.length) {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '暂无更多...'
                })
            }, 1000)
        } else {
            this.setState({
                loadingTxt: '加载中...'
            })
            setTimeout(() => {
                this.setState({
                    loadingTxt: '加载更多...',
                    itemNum: this.state.itemNum + 2,
                })
            }, 1000)
        }
    }
    goDetails(item){//跳转详情页面
        this.props.history.push({
            pathname:'/details',
            query:{
                details_item:item
            }
        })
    }
    render(){
        //计划列表
        console.log(this.state.plans);
        
        var planLists = this.state.plans.map((item, index) => {
            return item
        }).filter((item, index) => {
            return index < this.state.itemNum
        }).map((item, index) => {
            return <Index_plan
                godetails={(item)=>{this.goDetails(item)}}
                plan_item={item}
                key={item._id}
            />
        })
        return(
            <div className='Myplan clearfix'>
                <div className='search_header'>
                    {/* <img src="http://m.jirou.com/templets/jirouweb/images/logo.png" alt="" className="header_logo" /> */}
                    <NavBar
                        mode="light"
                        icon={<Icon type="left" />}
                        onLeftClick={() => { this.onLeftClick() }}
                        rightContent={[
                            <Icon key="0" type="search" style={{ marginRight: '16px' }} />,
                            <Icon key="1" type="ellipsis" />,
                        ]}
                    >推荐计划</NavBar>
                </div>
                <div className="search_box">
                    <SearchBar
                        value={this.state.value}
                        placeholder="搜索"
                        onSubmit={value => console.log(value, 'onSubmit')}
                        onClear={value => console.log(value, 'onClear')}
                        onFocus={() => console.log('onFocus')}
                        onBlur={() => console.log('onBlur')}
                        onCancel={() => console.log('onCancel')}
                        showCancelButton
                        onChange={this.onChange}
                    />
                </div>
                <div className='index_plan index_item'>
                    <div className='header clearfix'>
                    </div>
                    <ul className='index_item_box'>
                        {planLists}
                    </ul>
                </div>
                <div className="loading_box" id='loading_box' onClick={() => { this.getLoading() }}>{this.state.loadingTxt}</div>
                <NoticeBar mode="link" onClick={() => alert('谢谢您的支持!')}>
                    This article is owned by the author. If you need to check the original or reprint it, please contact the author. Please understand. Thank you!
                </NoticeBar>
                <div className='footer'>
                    <img src="http://m.jirou.com/templets/jirouweb/images/footer.png" alt="" />
                </div>
            </div>
        )
    }
}

//推荐计划组件
class Index_plan extends Component {
    constructor() {
        super();
    }
    goDetails(item){
        this.props.godetails(item)
    }
    render() {
        return (
            <li className='index_item_item_2' onClick = {()=>{this.goDetails(this.props.plan_item)}}>
                <div className='item_img'><img src={this.props.plan_item.src} alt="" /></div>
                <div className="item_txt">
                    <div className='item_txt_top'>
                        {this.props.plan_item.title}
                </div>
                    <div className='item_txt_bootom'>
                        {this.props.plan_item.time}
                </div>
                </div>
            </li>
        )
    }
}