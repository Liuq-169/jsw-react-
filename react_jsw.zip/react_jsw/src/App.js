import React,{lazy,Suspense} from 'react';
import './App.css';
import "antd-mobile/dist/antd-mobile.css";
import {BrowserRouter as Router ,Route,Switch,Redirect} from "react-router-dom"
// import Dashbord from './page/Dashbord'
// import Login from './page/Login'
// 使用lazy
let Dashbord = lazy(()=>import('./page/Dashbord')) //
let Login = lazy(()=>import('./page/Login')) //
let Plan = lazy(()=>import('./page/Plan')) //
let Action = lazy(()=>import('./page/Action')) //
let Details = lazy(()=>import('./page/Details')) //
let Course = lazy(()=>import('./page/Course')) //
let User = lazy(()=>import('./page/User')) //
let Updata_user = lazy(()=>import('./page/Updata_user')) //

//Link navLink我们称为模板导航
function App() {
  return (
    <Router>
      <div className="App">
        <Suspense fallback={<div>Loading...</div>}>
          <Switch>
            
            <Route path='/login' component={Login} exact></Route>
            <Route path='/updata_user' component={Updata_user} ></Route>
            <Route path='/user' component={User} ></Route>
            <Route path='/details' component={Details}></Route>
            <Route path='/index/course' component={Course}></Route>
            <Route path='/index/plan' component={Plan}></Route>
            <Route path='/index/action' component={Action}></Route>
            <Route path='/' component={Dashbord}></Route>
            <Route render={()=>{return(<span>404</span>)}}></Route>
          </Switch>
        </Suspense>
      </div>
    </Router>
  );
}

export default App;
