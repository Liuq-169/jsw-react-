// 定义comment的action的地方
import { ADDCOMMENT, DELETECOMMENT, FETCHCOMMENT } from './actions-type'



//在实际开发中，会把action定义为一个函数返回一个对象
export let addcomment = function (obj) {
    return {
        type: ADDCOMMENT, //函数类型
        comment: obj //携带的参数
    }
}
let fetchcomment = function (arr) {
    return {
        type: FETCHCOMMENT,
        comments:arr
    }
}

export let deletecomment = function (_id) {
    return {
        type: DELETECOMMENT,
        _id: _id
    }
}

export let syncfetchcomment = function () {
    return (dispatch) => {
        //异步
        setTimeout(() => {
            dispatch(fetchcomment({
                Carousel:[{
                    _id: 'Carousel01',
                    src:'https://www.jirou.com/uploads/allimg/190713/150-1ZG31I6204K.jpg'
    
                }, {
                    _id: 'Carousel02',
                    src:'https://www.jirou.com/uploads/allimg/190713/150-1ZG31K20QN.jpg'
    
                }, {
                    _id: 'Carousel02',
                    src:'https://m.jianshen8.com/templets/jianshen8/images/xgn01.jpg'
    
                }],
            }))
        }, 1000)
    }
}