let comment = function (state = [], action) {
    switch (action.type) {
        case 'ADDCOMMENT':
            return [...state,action.obj]
        case 'FETCHCOMMENT'://获取创建的数据
            return [...state,...action.comments.Carousel]
        case 'DELETECOMMENT'://进行删除创建 的数据
            return state.filter((item)=>{
                return item._id != action._id
            })
        default:
            return state
    }
}
export default comment