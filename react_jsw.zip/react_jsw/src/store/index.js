import { createStore,combineReducers,applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import comment from './reducers/comment'
let store = createStore(comment,applyMiddleware(thunk))//使用了thunk这个插件
export default store
