import { createStore,combineReducers } from 'redux'

//createStore这个方法就是用创建store的函数
//动态的加或者 减一个state里面的count
//定义reducer 纯函数 修改状态的地方，注意，reducer不做修改对象的属性值的操作，而是直接返回新state

var reducer = function (state = 0, actions) {
    switch (actions.type) {
        case 'ADD':
            return state + actions.preload
        default:
            return state
    }
}

var job = [{
    position: "高级吹牛B工程师",
    id: "QF001"
}]
var jobs = function (state = job, action) {
    switch (action.type) {
        case 'REMOVE':
            return state.filter((item) => {
                return item.id != action.id
            })
        default:
            return state
    }
}

var todos = combineReducers({
    reducer,
    jobs
})

var store = createStore(todos)//工厂模式，传递参数:参数就是你定义的reducer


store.subscribe(() => { //订阅state的改变
    console.log(store.getState());
})
//action:是一个普通函数，描述用户想要执行的动作

// store.dispatch({
//     type: 'ADD',
//     preload: 2
// })

store.dispatch({
    type: 'REMOVE',
    id: "QF001"
})


export default store